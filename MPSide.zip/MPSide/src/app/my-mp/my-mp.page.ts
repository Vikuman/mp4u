import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-mp',
  templateUrl: './my-mp.page.html',
  styleUrls: ['./my-mp.page.scss'],
})
export class MyMPPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
