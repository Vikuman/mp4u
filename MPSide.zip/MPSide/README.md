<h1 align="center">meu-starter.tabs-sidemenu.ionic-v4</h1>
<div align="center">
  <strong>Combine side menu, tabs and login page with Ionic 4</strong>
</div>
<div align="center">
  <h3>
    <a href="http://meumobi.github.io/ionic/2018/11/13/side-menu-tabs-login-page-ionic4.html">
      Tutorial
    </a>
  </h3>
</div>

## Getting Started

* [Download the installer](https://nodejs.org/) for Node.js 6 or greater.
* Install the ionic CLI globally: `npm install -g ionic`
* Clone this repository: `git clone https://github.com/meumobi/meu-starter.tabs-sidemenu.ionic-v4.git`.
* Run `npm install` from the project root.
* Run `ionic serve` in a terminal from the project root.
* Profit. :tada:
